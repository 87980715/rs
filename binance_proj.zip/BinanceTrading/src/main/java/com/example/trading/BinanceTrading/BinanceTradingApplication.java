package com.example.trading.BinanceTrading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BinanceTradingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BinanceTradingApplication.class, args);
	}

}
