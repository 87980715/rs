/**
 * 
 */
package com.pack.binance.model;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "liveorderbook")
public class LiveOrderBook {

	private Integer id;
	private Double quantity;
	private String symbol;
	private Double price;
	private String status;
	@Column(name = "trading_done")
	private Integer tradingDone;
	@Column(name = "order_id")
	private Integer orderId;

	@Override
	public String toString() {
		return "LiveOrderBook [id=" + id + ", quantity=" + quantity + ", symbol=" + symbol + ", price=" + price
				+ ", status=" + status + ", tradingDone=" + tradingDone + ", orderId=" + orderId + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getTradingDone() {
		return tradingDone;
	}

	public void setTradingDone(Integer tradingDone) {
		this.tradingDone = tradingDone;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

}
