package com.pack.binance.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pack.binance.model.LiveOrderBook;

public interface LiveOrderBookRepository extends JpaRepository<LiveOrderBook, Integer>{
	

}
