package com.pack.binance.utils;

import java.math.BigDecimal;

public class ComputeValue {

	public static BigDecimal percentage(BigDecimal base, BigDecimal percentage) {
		return base.multiply(percentage);
	}
}
